function calculateRetirementPortfolio() {
    // Get the values from the input fields
    var PV = parseFloat(document.getElementById('pv').value);
    var n = parseFloat(document.getElementById('age').value);
    var i = parseFloat(document.getElementById('rate').value) / 100;
    var R = parseFloat(document.getElementById('contribution').value);
    var salary = parseFloat(document.getElementById('salary').value);

    // Calculate the Future Value of the retirement portfolio
    var FV = PV * Math.pow((1 + i), n) + (R * (Math.pow((1 + i), n) - 1) / i);
    var yearlyPayout = FV / 15; // Retirement years assumed to be 15

    // Format the numbers with commas
    var formattedFV = FV.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    var formattedYearlyPayout = yearlyPayout.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    
    // Display the result with formatted numbers
    document.getElementById('result').innerText = 'Future Portfolio Value: $' + formattedFV;
    document.getElementById('yearlyPayout').innerText = 'Yearly Payout After Retirement: $' + formattedYearlyPayout;
    
    // Compare with current annual income
    var comparisonResult = salary > yearlyPayout ? "Your current income is higher than the projected yearly retirement payout." : "Your projected yearly retirement payout is higher than the current income.";
    document.getElementById('comparison').innerText = comparisonResult;
}

window.onload = function() {
    document.getElementById('calculate').onclick = calculateRetirementPortfolio;
}
